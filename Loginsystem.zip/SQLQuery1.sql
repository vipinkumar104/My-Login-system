﻿alter proc adduser
@Name varchar(50),
@gender varchar(50),
@age varchar(50),
@contact varchar(50),
@email varchar(50),
@adress varchar(50),
@postcode varchar(50),
@password varchar(50)
as
insert into account(Name,gender,age,contact,email,adress,postcode,password)
values (@Name,@gender,@age,@contact,@email,@adress,@postcode,@password)
