﻿CREATE proc feed
@nameuser varchar(50),
@creative varchar(50),
@leadership varchar(50),
@hardwork varchar(50),
@punctual varchar(50),
@work varchar(50),
@coding varchar(50)

as
insert into feedbk(nameuser,creative,leadership,hardwork,punctual,work,coding)
values (@nameuser,@creative,@leadership,@hardwork,@punctual,@work,@coding)